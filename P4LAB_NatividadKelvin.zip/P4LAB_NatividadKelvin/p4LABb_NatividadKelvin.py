import turtle

turtle.right(90)
turtle.forward(150)
turtle.left(180)
turtle.forward(75)
turtle.right(45)
turtle.forward(100)
turtle.right(180)
turtle.forward(100)
turtle.left(90)
turtle.forward(100)

turtle.penup()
turtle.left(45)
turtle.forward(100)

turtle.pendown()
turtle.left(90)
turtle.forward(150)
turtle.left(180)
turtle.left(20)
turtle.forward(160)
turtle.right(20)
turtle.left(180)
turtle.forward(150)


