import turtle

for i in range(3):
    turtle.forward(100)
    turtle.left(120)

turtle.right(180)
turtle.penup()
turtle.forward(100)
turtle.pendown()

for i in range (4):
    turtle.right(90)
    turtle.forward(100)
